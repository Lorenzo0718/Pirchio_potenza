/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pirchio_potenzaproj;

/**
 *
 * @author ospite
 */
public class Pirchio_potenzaProj {

    public static void main(String[] args) {
        
        potenza out = new potenza();
        
        System.out.print(out.v_risultato);
        
    }
}
